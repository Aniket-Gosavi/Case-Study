package com.aniket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
